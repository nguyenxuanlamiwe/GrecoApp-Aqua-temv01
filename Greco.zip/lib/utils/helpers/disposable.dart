class Disposable {
  void dispose() {}
}
